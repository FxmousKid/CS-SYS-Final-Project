Tâche 12 : Jamais exécutée. Lance la séquence
             `(echo "Maman, les p'tits bateaux"; echo "Qui vont sur l'eau"; echo "Ont-ils des rames ?"; true)`
Tâche 13 : Jamais exécutée. Lance la séquence
             `(echo "Maman, les p'tits bateaux"; echo "Qui vont sur l'eau"; echo "Ont-ils des voiles ?"; true)`
Tâche 14 : Jamais exécutée. Lance la séquence
             `(echo "Maman, les p'tits bateaux"; echo "Qui vont sur l'eau"; echo "Ont-ils des jambes ?"; false)`
Ce sont ces 3 tâches qui ont été combinées pour donner l'exemple 3
