Tâche 4 : Toutes les minutes, lance la séquence
          ```
          echo -n "Nous sommes le ";
          date "+%d/%m/%Y";
          echo -n "Il est ";
          date "+%H:%M:%S"
          ```
Cette tâche a déjà été lancée deux fois
