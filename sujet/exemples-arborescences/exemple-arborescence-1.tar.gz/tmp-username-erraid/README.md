Tâche 0 : Toutes les minutes, tous les jours sauf le lundi, lance la commande
         `echo "Feed me lasagna"`
Tâche 1 : Toutes les heures (à l'heure pile), le lundi, lance la commande
         `echo "I hate mondays"`
Aucune des deux commandes n'a encore été lancée
